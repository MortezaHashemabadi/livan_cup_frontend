"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Send } from "lucide-react";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useNotify } from "@/lib/notifications";

type ContactFormState = {
  fullName: string;
  phone: string;
  subject: string;
  message: string;
};

const emptyForm: ContactFormState = {
  fullName: "",
  phone: "",
  subject: "",
  message: "",
};

export default function ContactForm() {
  const [form, setForm] = useState<ContactFormState>(emptyForm);
  const notify = useNotify();

  const handleChange =
    (field: keyof ContactFormState) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setForm((prev) => ({ ...prev, [field]: e.target.value }));
    };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    notify({
      type: "success",
      title: "پیام شما ارسال شد",
      message: "به زودی با شما تماس می‌گیریم.",
    });

    setForm(emptyForm);
  };

  return (
    <section className="py-24 bg-background">
      <div className="max-w-3xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="inline-block text-xs font-semibold tracking-widest uppercase text-cobalt mb-4">
            فرم تماس
          </span>

          <h2 className="font-display font-extrabold text-3xl md:text-4xl tracking-tight">
            پیام خود را برای ما ارسال کنید
          </h2>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          onSubmit={handleSubmit}
          className="bg-white rounded-[32px] border border-border p-8 md:p-10 space-y-6"
        >
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="fullName">نام و نام خانوادگی</Label>
              <Input
                id="fullName"
                value={form.fullName}
                onChange={handleChange("fullName")}
                required
                placeholder="مثلاً امیر محمدی"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">شماره تماس</Label>
              <Input
                id="phone"
                value={form.phone}
                onChange={handleChange("phone")}
                required
                placeholder="۰۹۱۲۳۴۵۶۷۸۹"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">موضوع</Label>
            <Input
              id="subject"
              value={form.subject}
              onChange={handleChange("subject")}
              required
              placeholder="موضوع پیام شما"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">پیام</Label>
            <Textarea
              id="message"
              value={form.message}
              onChange={handleChange("message")}
              required
              rows={5}
              placeholder="پیام خود را بنویسید..."
            />
          </div>

          <Button
            type="submit"
            size="lg"
            className="w-full bg-cobalt hover:bg-cobalt-hover text-white rounded-full h-14 font-medium text-base shadow-none"
          >
            ارسال پیام
            <Send className="w-4 h-4 mr-2" />
          </Button>
        </motion.form>
      </div>
    </section>
  );
}
